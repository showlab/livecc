# livecc-utils

LiveCC Utils is a supplement to qwen-vl-utils, which contains a set of helper functions for processing and integrating visual language information with LiveCC Model.

## Install

```bash
pip install livecc-utils
```

## Usage

### Real-Time Video Commentary

### General Video Caption/QA